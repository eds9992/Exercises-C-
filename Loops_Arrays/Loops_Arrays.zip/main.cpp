/*
Modify the 10 grade file I/O problem so that your program reads the data from the file into an array
and then uses a for loop to find the average, highest, and lowest values by accessing the array.
*/


#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
    srand(time(0));
    ofstream outFile;
    ifstream inFile;
    outFile.open("grades.txt");
    int grade;
    int count = 1;
    const int numGrades = 10;
    while (count <= numGrades)
    {
        grade = rand() % 50 + 50;
        outFile << grade << endl;
        ++count;
    }
    outFile.close();
    const int arraySize = 10;
    int Grades[arraySize];
    int sum, highest, lowest;
    double average = 0.0;
    inFile.open("grades.txt");
    inFile >> Grades[arraySize];
    cout << grade << " ";
    highest = grade;
    lowest = grade;
    sum += grade;
    /*for(int i = grade; i < Grades[arraySize]; ++i)
    {
        cout << Grades[arraySize] << " ";
        sum += grade;
        if (grade > highest)
        {
            highest = grade;
        }
        if (grade < lowest)
        {
            lowest = grade;
        }
        average = sum / static_cast<double>(numGrades);
    }*/
    while (inFile >> grade)
    {
       cout << grade << " ";
       sum += grade;
       if (grade > highest)
       {
           highest = grade;
       }
       if (grade < lowest)
       {
           lowest = grade;
       }
    }
    average = sum / static_cast<double>(numGrades);
    cout << endl << endl;
    cout << "The average is: " << average << endl;
    cout << "The highest value is: " << highest << endl;
    cout << "The lowest value is: " << lowest << endl;
    return 0;
}

/*
    ofstream outfile;
    outfile.open("GradePoint.txt");
    outfile << 87 << endl;
    outfile << 88 << endl;
    outfile << 95 << endl;//High Grade
    outfile << 72 << endl;
    outfile << 102 << endl;
    outfile << 84 << endl;
    outfile << 86 << endl;
    outfile << 62 << endl;//Low Grade
    outfile << 83 << endl;
    outfile << 85 << endl;
    outfile.close();
    ifstream infile;
    infile.open("GradePoint.txt");
    int sum = 0;
    int number;
    int low = 101;
    int high = 0;
    while (infile >> number)
    {
        cout << number << endl;
        sum += number;
        if (number < low)
        {
            low = number;
        }
        else if (number > high)
        {
            high = number;
        }
    }
    int avg = sum / 10;
    cout << "Average is: " << avg << endl;
    cout << "Lowest grade is " << low << endl;
    cout << "Highest grade is " << high << endl;
    infile.close();
    return 0;


    //const int numGrades = 5;
    int grades[5];
    grades[0] = 81;
    grades[1] = 77;
    grades[2] = 92;
    grades[3] = 100;
    grades[4] = 89;
    for (unsigned int i = 0; i < 5; i++) //Unsigned means int can never be negative
    {
        cout << grades[i] << " ";
    }
    return 0;
*/
